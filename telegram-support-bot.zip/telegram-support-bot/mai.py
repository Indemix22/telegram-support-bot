from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters
import os

TOKEN = os.getenv("BOT_TOKEN")
SUPPORT_CHAT_ID = int(os.getenv("SUPPORT_CHAT_ID"))

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Привіт! Напишіть ваше запитання, і наш менеджер скоро відповість.")

async def forward_to_support(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text = update.message.text
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton(f"Відповісти {user.first_name}", callback_data=f"reply_{user.id}")]
    ])
    await context.bot.send_message(
        chat_id=SUPPORT_CHAT_ID,
        text=f"📩 Нове повідомлення від [{user.first_name}](tg://user?id={user.id}):\n\n{text}",
        reply_markup=keyboard,
        parse_mode='Markdown'
    )
    await update.message.reply_text("Ваше повідомлення надіслано менеджеру. Очікуйте відповідь.")

async def handle_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.data.startswith("reply_"):
        user_id = int(query.data.split("_")[1])
        await context.bot.send_message(
            chat_id=query.message.chat_id,
            text=f"Використайте команду:\n\n`/reply {user_id} Ваш текст відповіді`",
            parse_mode="Markdown"
        )

async def reply(update: Update, context: ContextTypes.DEFAULT_TYPE):
    args = context.args
    if len(args) < 2:
        await update.message.reply_text("⚠️ Формат: /reply user_id повідомлення")
        return
    user_id = int(args[0])
    reply_text = " ".join(args[1:])
    try:
        await context.bot.send_message(chat_id=user_id, text=f"💬 Менеджер: {reply_text}")
        await update.message.reply_text("✅ Повідомлення надіслано.")
    except Exception as e:
        await update.message.reply_text(f"Помилка надсилання: {e}")

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("reply", reply))
    app.add_handler(CallbackQueryHandler(handle_callback))
    app.add_handler(MessageHandler(filters.TEXT & (~filters.COMMAND), forward_to_support))
    app.run_polling()

if __name__ == "__main__":
    main()
